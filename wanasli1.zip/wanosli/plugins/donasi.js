let handler = async m => m.reply(`
╭─「 Donasi • Pulsa 」
│ • Im3 [085794065296]
│ • Im3 [085703153719]
╰────
╭─「 Hubungi 」
│ > Ingin donasi? Wa.me/6285794065296
╰────
`.trim()) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler
